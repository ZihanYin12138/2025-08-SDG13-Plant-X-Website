#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
AWS Lambda函数入口 - 植物推荐系统

此文件作为AWS Lambda函数的入口点，处理来自API Gateway的请求，
并调用植物推荐系统生成推荐结果。
"""

import json
import os
import sys
from typing import Dict, Any, Optional

# 添加当前目录到Python路径，以便导入plant_recommendation模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from plant_recommendation_lambda import get_plant_recommendations

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    AWS Lambda函数处理器
    
    Args:
        event: API Gateway事件对象
        context: Lambda上下文对象
        
    Returns:
        API Gateway响应格式的字典
    """
    try:
        # 验证必需的环境变量
        required_env_vars = ['DB_HOST', 'DB_NAME', 'DB_PASSWORD', 'DB_USER']
        missing_vars = [var for var in required_env_vars if not os.environ.get(var)]
        if missing_vars:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
                },
                'body': json.dumps({
                    'error': '配置错误',
                    'message': f'缺少必需的环境变量: {", ".join(missing_vars)}'
                })
            }
        
        # 解析请求参数
        if event.get('httpMethod') == 'GET':
            # 从查询参数获取经纬度
            query_params = event.get('queryStringParameters') or {}
            latitude = float(query_params.get('lat', -37.8136))
            longitude = float(query_params.get('lon', 144.9631))
        elif event.get('httpMethod') == 'POST':
            # 从请求体获取经纬度
            try:
                body_str = event.get('body', '{}')
                if not body_str or body_str.strip() == '':
                    body_str = '{}'
                body = json.loads(body_str)
                latitude = float(body.get('latitude', -37.8136))
                longitude = float(body.get('longitude', 144.9631))
            except json.JSONDecodeError as e:
                return {
                    'statusCode': 400,
                    'headers': {
                        'Content-Type': 'application/json',
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
                    },
                    'body': json.dumps({
                        'error': 'JSON解析错误',
                        'message': f'请求体不是有效的JSON格式: {str(e)}',
                        'expected_format': {
                            'latitude': -37.8136,
                            'longitude': 144.9631
                        }
                    })
                }
        else:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
                },
                'body': json.dumps({
                    'error': '不支持的HTTP方法',
                    'message': '仅支持GET和POST请求'
                })
            }
        
        # 验证经纬度范围
        if not (-90 <= latitude <= 90) or not (-180 <= longitude <= 180):
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
                },
                'body': json.dumps({
                    'error': '无效的坐标参数',
                    'message': '纬度必须在-90到90之间，经度必须在-180到180之间'
                })
            }
        
        # 调用植物推荐系统
        weather_info, plant_ids = get_plant_recommendations(latitude, longitude)
        
        if weather_info is None or plant_ids is None:
            return {
                'statusCode': 500,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
                },
                'body': json.dumps({
                    'error': '推荐生成失败',
                    'message': '无法获取天气数据或植物数据'
                })
            }
        
        # 构建成功响应
        response_data = {
            'success': True,
            'latitude': latitude,
            'longitude': longitude,
            'aggregated_weather': weather_info,
            'recommended_plant_ids': plant_ids,
            'total_recommendations': len(plant_ids)
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            'body': json.dumps(response_data, ensure_ascii=False, indent=2)
        }
        
    except ValueError as e:
        # 参数解析错误
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            'body': json.dumps({
                'error': '参数错误',
                'message': str(e)
            })
        }
        
    except Exception as e:
        # 其他未预期的错误
        print(f"Lambda函数执行错误: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            'body': json.dumps({
                'error': '服务器内部错误',
                'message': '推荐系统暂时不可用'
            })
        }

def handle_cors_preflight(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    处理CORS预检请求
    """
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
        },
        'body': ''
    }
