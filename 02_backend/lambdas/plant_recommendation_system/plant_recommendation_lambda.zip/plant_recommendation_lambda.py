# .py version of 01_plant_recommendation.ipynb - Lambda优化版本
# Name: Zihan

#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Weather-Based Plant Recommendation Engine - Lambda Optimized Version

This script fetches a 16-day weather forecast for a given location,
loads plant data from a MySQL database, and recommends suitable plants
based on a set of matching rules. Optimized for AWS Lambda without pandas/numpy.
"""

import requests
import json
import random
import os
from common.db_utils import fetch_all

# ==============================================================================
# 1. 常量与配置 (Constants and Configuration)
# ==============================================================================

# 耐寒区到温度(°C)的转换表
HARDINESS_ZONE_TO_CELSIUS = {
    "1": -51.1, "2": -45.6, "3": -40.0, "4": -34.4, "5": -28.9,
    "6": -23.3, "7": -17.8, "8": -12.2, "9": -6.7, "10": -1.1,
    "11": 4.4,  "12": 10.0, "13": 15.6
}

# ==============================================================================
# 2. 函数定义 (Function Definitions)
# ==============================================================================

def load_plants_from_db():
    """从MySQL数据库加载植物数据并进行预处理。"""
    plants = []  # 使用列表代替DataFrame
    try:
        print("--> 正在连接MySQL数据库...")
        query = "SELECT * FROM Table13_GeneralPlantListforRecommendation;"
        rows = fetch_all(query)
        plants = list(rows)  # 转换为列表
        print(f"--> 成功从数据库加载 {len(plants)} 种植物。")
    except Exception as e:
        print(f"!! 从MySQL加载数据时发生错误: {e}")
        return []

    # 预处理数据
    for plant in plants:
        if plant.get('sunlight'):
            try:
                plant['sunlight'] = json.loads(plant['sunlight']) if isinstance(plant['sunlight'], str) else plant['sunlight']
            except:
                plant['sunlight'] = []
        if plant.get('drought_tolerant'):
            plant['drought_tolerant'] = bool(plant['drought_tolerant'])
    
    return plants

def get_default_weather_data():
    """获取默认天气数据（当API失败时使用）"""
    print("--> 使用默认天气数据")
    return {
        'extreme_min_temp': 5.0,  # 默认最低温度
        'extreme_max_temp': 25.0,  # 默认最高温度
        'avg_sunshine_duration': 6.0,  # 默认平均日照
        'avg_max_uv_index': 5.0,  # 默认UV指数
        'avg_daily_precipitation': 3.0,  # 默认降水量
        'avg_relative_humidity': 60.0  # 默认湿度
    }

def get_and_aggregate_weather_data(latitude, longitude):
    """根据经纬度获取并聚合天气数据。"""
    api_url = (
        f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}"
        "&daily=precipitation_sum,sunshine_duration,uv_index_max,temperature_2m_max,"
        "temperature_2m_min,relative_humidity_2m_mean&timezone=auto&forecast_days=16"
    )
    
    # 设置超时和重试
    max_retries = 3
    timeout = 10  # 10秒超时
    
    weather_data = None
    for attempt in range(max_retries):
        try:
            print(f"--> 尝试获取天气数据 (第{attempt + 1}次)...")
            response = requests.get(api_url, timeout=timeout)
            response.raise_for_status()
            weather_data = response.json()['daily']
            print(f"--> 天气数据获取成功")
            break
        except requests.exceptions.Timeout as e:
            print(f"!! 请求超时 (第{attempt + 1}次): {e}")
            if attempt == max_retries - 1:
                print("!! 所有重试都超时，使用默认天气数据")
                return get_default_weather_data()
        except requests.exceptions.RequestException as e:
            print(f"!! API请求失败 (第{attempt + 1}次): {e}")
            if attempt == max_retries - 1:
                print("!! 所有重试都失败，使用默认天气数据")
                return get_default_weather_data()
        except Exception as e:
            print(f"!! 未知错误 (第{attempt + 1}次): {e}")
            if attempt == max_retries - 1:
                print("!! 所有重试都失败，使用默认天气数据")
                return get_default_weather_data()

    # 如果成功获取天气数据，进行处理
    if weather_data:
        def clean_list(data_list):
            return [item for item in data_list if item is not None]

        temp_min_list = clean_list(weather_data['temperature_2m_min'])
        temp_max_list = clean_list(weather_data['temperature_2m_max'])
        sunshine_list = clean_list(weather_data['sunshine_duration'])
        uv_list = clean_list(weather_data['uv_index_max'])
        precipitation_list = clean_list(weather_data['precipitation_sum'])
        humidity_list = clean_list(weather_data['relative_humidity_2m_mean'])
        
        # 使用纯Python实现聚合计算
        aggregated_weather = {
            'extreme_min_temp': min(temp_min_list) if temp_min_list else None,
            'extreme_max_temp': max(temp_max_list) if temp_max_list else None,
            'avg_sunshine_duration': (sum(sunshine_list) / len(sunshine_list) / 3600) if sunshine_list else None,
            'avg_max_uv_index': sum(uv_list) / len(uv_list) if uv_list else None,
            'avg_daily_precipitation': sum(precipitation_list) / len(precipitation_list) if precipitation_list else None,
            'avg_relative_humidity': sum(humidity_list) / len(humidity_list) if humidity_list else None
        }
        
        return {
            key: round(value, 2) if isinstance(value, float) else value
            for key, value in aggregated_weather.items()
        }
    else:
        # 如果所有重试都失败，返回默认数据
        return get_default_weather_data()

def is_plant_suitable(agg_weather, plant):
    """核心匹配逻辑：判断单个植物是否符合天气条件。"""
    if agg_weather.get('extreme_min_temp') is None: 
        return False  # 如果天气数据无效，则无法判断
    
    # 规则 1: 生存底线
    if agg_weather['extreme_min_temp'] < plant['absolute_min_temp_c']:
        return False

    # 规则 2: 日照需求
    sun_duration = agg_weather.get('avg_sunshine_duration', 0)
    uv_index = agg_weather.get('avg_max_uv_index', 0)
    sunlight_needs = plant.get('sunlight', [])
    sun_duration_ok = False
    
    if 'full sun' in sunlight_needs and sun_duration >= 6: 
        sun_duration_ok = True
    if ('part shade' in sunlight_needs or 'part sun/part shade' in sunlight_needs) and (3 <= sun_duration < 6): 
        sun_duration_ok = True
    if 'full shade' in sunlight_needs and sun_duration < 3: 
        sun_duration_ok = True
    if not sun_duration_ok: 
        return False
    if uv_index > 8 and sunlight_needs == ['part shade']: 
        return False
    if uv_index < 3 and sunlight_needs == ['full sun']: 
        return False

    # 规则 3: 浇水需求
    precipitation = agg_weather.get('avg_daily_precipitation', 0)
    watering_needs = plant.get('watering', '')
    if watering_needs == 'Frequent' and precipitation < 3: 
        return False
    if watering_needs == 'Minimal' and precipitation > 5: 
        return False
    if watering_needs == 'Average' and not (1 <= precipitation <= 8): 
        return False

    # 规则 4: 抗旱性
    humidity = agg_weather.get('avg_relative_humidity', 0)
    if not plant.get('drought_tolerant', False) and humidity < 40: 
        return False

    return True

def get_plant_recommendations(latitude, longitude):
    """主协调函数，执行完整的推荐流程。"""
    print(f"\n为经纬度 ({latitude}, {longitude}) 生成植物推荐报告...")
    
    plants = load_plants_from_db()
    if not plants:
        print("!! 无法加载植物数据，推荐流程终止。")
        return None, None
    
    agg_weather = get_and_aggregate_weather_data(latitude, longitude)
    if not agg_weather:
        print("!! 无法获取天气数据，推荐流程终止。")
        return None, None
        
    # 筛选适合的植物
    suitable_plants = []
    for plant in plants:
        if is_plant_suitable(agg_weather, plant):
            suitable_plants.append(plant)
    
    # 提取植物ID并随机排序
    suitable_plant_ids = [plant['general_plant_id'] for plant in suitable_plants]
    random.shuffle(suitable_plant_ids)
    
    return agg_weather, suitable_plant_ids

# ==============================================================================
# 3. 主执行模块 (Main Execution Block)
# ==============================================================================

if __name__ == "__main__":
    # 测试函数
    weather_info, plant_ids = get_plant_recommendations(latitude=-37.8136, longitude=144.9631)
    
    if weather_info and plant_ids is not None:
        print("\n" + "="*50)
        print("      未来16天聚合天气信息      ")
        print("="*50)
        for key, value in weather_info.items():
            print(f"{key}: {value}")
        
        print("\n" + "="*50)
        print("      符合种植条件的植物ID列表 (已随机排序)      ")
        print("="*50)
        if plant_ids:
            print(plant_ids)
        else:
            print("根据未来天气，未找到特别符合条件的植物。")
        print("="*50)